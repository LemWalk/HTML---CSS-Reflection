<form action="#" method="get" >
		<div class="container-inner" id="form-lo">

			<div>
				<h2>Email Newsletter Sign-Up</h2>
			</div>

			<div class="input-boxes">
			
					<div class="data-input">
						<label id="name-id" for="form-input-name">Your Name <span class="p-red">*</span></label>
						<input id="form-input-name" type="text">
					</div>

					<div class="data-input">
						<label id="e-mail-id" for="form-input-email">Your Email <span class="p-red">*</span></label>
						<input id="form-input-email" type="text">
					</div>

				</div>

			<div class="checkbox">
        <span class="custom-tickbox"></span>
				<input type="checkbox" class="tickbox" id="checkbox-id" name="#" value="#">
                <label for="checkbox-id" class="form-text">Please tick this box if you wish to receive marketing information from us. Please see our <a href="#" class="link-blk">Privacy Policy</a> for more information on how we keep your data safe.</label>
        </div>

			<div>
				<button type="submit" class="btn-blk">SUBSCRIBE</button>
			</div>

		</div>
	</form> 