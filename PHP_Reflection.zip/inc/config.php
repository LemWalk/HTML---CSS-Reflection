<?php
$host = "localhost";
$dbname = "netmatters_reflection_db";
$username = "root";
$password = "";