<?php
$host = "localhost";
$dbname = "netmatters_reflection_db";
$username = "root";
$password = "";

// $host = "localhost";
// $dbname = "lemuelwa_netmatters_reflection_db";
// $username = "lemuelwa_lemuelwalkinshaw";
// $password = "NetM@tters123";